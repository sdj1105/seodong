package com.co.kr.free.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.co.kr.free.dao.FreeDao;
import com.co.kr.free.service.FreeService;

public class FreeServiceImpl implements FreeService {

	@Autowired
	private FreeDao freeDao;



}
