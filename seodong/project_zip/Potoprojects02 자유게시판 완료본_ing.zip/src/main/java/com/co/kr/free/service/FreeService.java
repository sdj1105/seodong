package com.co.kr.free.service;

public interface FreeService {

}
