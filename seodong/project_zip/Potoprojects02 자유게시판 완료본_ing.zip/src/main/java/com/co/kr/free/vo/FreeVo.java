package com.co.kr.free.vo;

public class FreeVo {

/*
    FREE_BOR_IDX NUMBER NOT NULL PRIMARY KEY,
    FREE_BOR_TITLE VARCHAR2(100) NOT NULL,
    USER_NM VARCHAR2(50),
    USER_ID VARCHAR2(50),
    FREE_BOR_CONTENTS VARCHAR2(1000),

    FREE_BOR_VIEW_CNT VARCHAR2(50),
    REG_DE DATE(50),
    UPDATE_ID VARCHAR2(50),
    UPDATE_DE DATE(50),
    DEL_DE DATE(50),

    DEL_ID VARCHAR2(20),
    DEL_YN DATE(50)
*/

	private String borIdx;
	private String borTitle;
	private String userNm;
	private String userId;
	private String freeBorContents;

	private String borViewCnt;
	private String regDe;
	private String updateId;
	private String updateDe;
	private String delDe;

	private String delId;
	private String delYn;

	public String getBorIdx() {
		return borIdx;
	}
	public void setBorIdx(String borIdx) {
		this.borIdx = borIdx;
	}
	public String getBorTitle() {
		return borTitle;
	}
	public void setBorTitle(String borTitle) {
		this.borTitle = borTitle;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFreeBorContents() {
		return freeBorContents;
	}
	public void setFreeBorContents(String freeBorContents) {
		this.freeBorContents = freeBorContents;
	}
	public String getBorViewCnt() {
		return borViewCnt;
	}
	public void setBorViewCnt(String borViewCnt) {
		this.borViewCnt = borViewCnt;
	}
	public String getRegDe() {
		return regDe;
	}
	public void setRegDe(String regDe) {
		this.regDe = regDe;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public String getUpdateDe() {
		return updateDe;
	}
	public void setUpdateDe(String updateDe) {
		this.updateDe = updateDe;
	}
	public String getDelDe() {
		return delDe;
	}
	public void setDelDe(String delDe) {
		this.delDe = delDe;
	}
	public String getDelId() {
		return delId;
	}
	public void setDelId(String delId) {
		this.delId = delId;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}


	@Override
	public String toString() {
		return "FreeVo [borIdx=" + borIdx + ", borTitle=" + borTitle + ", userNm=" + userNm + ", userId=" + userId
				+ ", freeBorContents=" + freeBorContents + ", borViewCnt=" + borViewCnt + ", regDe=" + regDe
				+ ", updateId=" + updateId + ", updateDe=" + updateDe + ", delDe=" + delDe + ", delId=" + delId
				+ ", delYn=" + delYn + ", getBorIdx()=" + getBorIdx() + ", getBorTitle()=" + getBorTitle()
				+ ", getUserNm()=" + getUserNm() + ", getUserId()=" + getUserId() + ", getFreeBorContents()="
				+ getFreeBorContents() + ", getBorViewCnt()=" + getBorViewCnt() + ", getRegDe()=" + getRegDe()
				+ ", getUpdateId()=" + getUpdateId() + ", getUpdateDe()=" + getUpdateDe() + ", getDelDe()=" + getDelDe()
				+ ", getDelId()=" + getDelId() + ", getDelYn()=" + getDelYn() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}


}
