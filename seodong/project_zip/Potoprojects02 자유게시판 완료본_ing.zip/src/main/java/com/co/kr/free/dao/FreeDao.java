package com.co.kr.free.dao;

import com.co.kr.common.dao.AbstractDAO;
import com.co.kr.free.vo.FreeVo;

public class FreeDao extends AbstractDAO {

	private final String Free_SQL = "freeSql."; /*userSql 네임스페이스 임*/

	public void selctFreeList(FreeVo freeVo){
		selectList(Free_SQL + "FreeSelectSuccess", freeVo);
	}

}
