package com.co.kr.free.controller;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.co.kr.free.service.FreeService;
import com.co.kr.user.controller.UserContoller;
import com.co.kr.user.vo.UserVo;

@Controller
public class FreeController {

	private Log log = LogFactory.getLog(UserContoller.class);

	@Autowired
	FreeService freeService;

	@RequestMapping(value="/mainPage")
	public String FreeBoard(@ModelAttribute("freeVo") UserVo userVo, Model model, HttpServletResponse response) throws Exception{
		return "redirect: /cmm/login/mainPage";

	}
}
