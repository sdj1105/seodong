package com.co.kr.common.login.service;

import com.co.kr.common.login.vo.LoginVo;

public interface LoginService {

	public LoginVo selectUserLogin(LoginVo loginVo);

}
